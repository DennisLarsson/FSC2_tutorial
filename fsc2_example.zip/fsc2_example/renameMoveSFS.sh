#sfs files from: /home/biogeoanalysis/RAD/spicatumGroup/vcf2sfs
cp ./niggal_sfs_jointMAFpop1_0.obs ./dichotomous/dichotomous_jointMAFpop1_0.obs
cp ./nigspi_sfs_jointMAFpop1_0.obs ./dichotomous/dichotomous_jointMAFpop2_0.obs
cp ./galspi_sfs_jointMAFpop1_0.obs ./dichotomous/dichotomous_jointMAFpop2_1.obs

cp ./niggal_sfs_jointMAFpop1_0.obs ./hybrid/hybrid_jointMAFpop1_0.obs
cp ./nigspi_sfs_jointMAFpop1_0.obs ./hybrid/hybrid_jointMAFpop2_0.obs
cp ./galspi_sfs_jointMAFpop1_0.obs ./hybrid/hybrid_jointMAFpop2_1.obs

cp ./niggal_sfs_jointMAFpop1_0.obs ./migration/migration_jointMAFpop1_0.obs
cp ./nigspi_sfs_jointMAFpop1_0.obs ./migration/migration_jointMAFpop2_0.obs
cp ./galspi_sfs_jointMAFpop1_0.obs ./migration/migration_jointMAFpop2_1.obs

cp ./niggal_sfs_jointMAFpop1_0.obs ./introgression/introgression_jointMAFpop1_0.obs
cp ./nigspi_sfs_jointMAFpop1_0.obs ./introgression/introgression_jointMAFpop2_0.obs
cp ./galspi_sfs_jointMAFpop1_0.obs ./introgression/introgression_jointMAFpop2_1.obs
