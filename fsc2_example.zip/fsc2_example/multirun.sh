NrRuns=1000
nrStarts=5
L=10

model1="dichotomous"
model2="hybrid"
model3="introgression"
model4="migration"

cd ${model1}

x=1
while [ $x -le $nrStarts ]
do
pwd
time fsc26 -t ${model1}.tpl -n ${NrRuns} -m -e ${model1}.est -M -L ${L} -c 0 -q --foldedSFS --removeZeroSFS
cat ${model1}/${model1}.bestlhoods >> ${model1}_iter${nrStarts}_${NrRuns}
x=$(( $x + 1 ))
done

cd ..

cd ${model2}

x=1
while [ $x -le $nrStarts ]
do
time fsc26 -t ${model2}.tpl -n ${NrRuns} -m -e ${model2}.est -M -L ${L} -c 0 -q --foldedSFS --removeZeroSFS
cat ${model2}/${model2}.bestlhoods >> ${model2}_iter${nrStarts}_${NrRuns}
x=$(( $x + 1 ))
done

cd ..

cd ${model3}

x=1
while [ $x -le $nrStarts ]
do
time fsc26 -t ${model3}.tpl -n ${NrRuns} -m -e ${model3}.est -M -L ${L} -c 0 -q --foldedSFS --removeZeroSFS
cat ${model3}/${model3}.bestlhoods >> ${model3}_iter${nrStarts}_${NrRuns}
x=$(( $x + 1 ))
done

cd ..

cd ${model4}

x=1
while [ $x -le $nrStarts ]
do
time fsc26 -t ${model4}.tpl -n ${NrRuns} -m -e ${model4}.est -M -L ${L} -c 0 -q --foldedSFS --removeZeroSFS
cat ${model4}/${model4}.bestlhoods >> ${model4}_iter${nrStarts}_${NrRuns}
x=$(( $x + 1 ))
done

cd ..
